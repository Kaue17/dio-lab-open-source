### Hello there 😁

Hello, my name is Kaue and I am passionate about data science and everything related to artificial intelligence. My profile is still under construction and I will soon add my projects :)

- 🧐 Currently learning **Data Science** and **IA**
- 🌎 Actively working on hands-on projects to sharpen my skills.
- 🎯 Always looking for new challenges and opportunities to collaborate.

---
## Contact me:
[![Instagram](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/kaueajp/)
[![Linkedin](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/kaueajp/)


